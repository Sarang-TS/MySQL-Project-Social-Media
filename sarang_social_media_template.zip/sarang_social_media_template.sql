/* =====================================================================
   SOCIAL MEDIA (IG CLONE) — STUDENT ANSWER TEMPLATE
   ===================================================================== */

USE ig_clone;


/* =====================================================================
   OBJECTIVE QUESTIONS
   ===================================================================== */

-- O1.
-- Are there any tables with duplicate or missing null values? If so, how
-- would you handle them?

-- 1.1 users -> username null values

select 
	id, 
	username,
    created_at
from users
where username is null
;

-- 1.2 users -> username duplicate

select
	username,
    count(*) as userCnt
from users
group by username
having count(*) > 1
;

-- 1.3 rows with NULL image_url / user_id / created_dat

select 
	id,
    image_url,
    user_id,
    created_dat
from photos
where image_url is null or user_id is null or created_dat is null
;

-- 1.4  duplicate (image_url, user_id) pairs

select 
	image_url,
    user_id,
    count(*) as dup
from photos
group by image_url, user_id
having count(*)>1
;

-- 1.5 comments — rows with NULL comment_text / user_id / photo_id / created_at

select 
	id,
    comment_text,
    user_id,
    photo_id,
    created_at
from comments
where comment_text is null or user_id is null or photo_id is null or created_at is null
;

-- 1.6 duplicate (comment_text, user_id, photo_id) triples

select
	comment_text,
    user_id,
    photo_id,
    count(*) as dupcnt
from comments 
group by comment_text, user_id, photo_id
having count(*)>1
;

-- 1.7 likes:  rows with NULL user_id / photo_id / created_at

select
	user_id,
    photo_id,
    created_at
from likes
where user_id is null or photo_id is null or created_at is null
;

-- 1.8 duplicate (user_id, photo_id) pairs

select
	user_id,
    photo_id,
    count(*) as dupCnt
from likes
group by user_id, photo_id
having count(*) > 1

;

-- 1.9 follows — rows with NULL follower_id / followee_id / created_at

select
	follower_id,
    followee_id,
    created_at
from follows
where follower_id is null or followee_id is null or created_at is null
;

-- 1.10 follows — duplicate (follower_id, followee_id) pairs

select
	follower_id,
    followee_id,
    count(*) as dup
from follows
group by follower_id, followee_id
having count(*)>1
;


-- O2.
-- What is the distribution of user activity levels (e.g., number of posts,
-- likes, comments) across the user base?

with post_count as (
	select user_id, count(id) as total_posts from photos group by user_id
    ),
    likes_count as (
    select user_id, count(photo_id) as total_likes from likes group by user_id
    ),
    comments_count as (
    select user_id, count(id) as total_comments from comments group by user_id
    )

select 
	u.id as user_id,
    u.username,
    coalesce(p.total_posts,0) as total_posts,
    coalesce(l.total_likes,0) as total_likes,
    coalesce(c.total_comments,0) as total_comments
from users u 
left join post_count p on p.user_id=u.id
left join likes_count l on l.user_id=u.id
left join comments_count c on c.user_id=u.id
;

-- O3.
-- Calculate the average number of tags per post (photo_tags and photos
-- tables).

select
	count(pt.tag_id)/count(distinct p.id) as AverageTags
from photos p
left join photo_tags pt 
on p.id=pt.photo_id
;

-- O4.
-- Identify the top users with the highest engagement rates (likes, comments)
-- on their posts and rank them.

WITH photo_engagement AS (
    SELECT p.id AS photo_id, p.user_id,
           COALESCE(l.like_count, 0) + COALESCE(c.comment_count, 0) AS engagement
    FROM photos p
    LEFT JOIN (
        SELECT photo_id, COUNT(*) like_count FROM likes GROUP BY photo_id ) l ON l.photo_id = p.id
    LEFT JOIN ( SELECT photo_id, COUNT(*) comment_count FROM comments GROUP BY photo_id ) c ON c.photo_id = p.id
),
user_totals AS (
    SELECT user_id, SUM(engagement) total FROM photo_engagement GROUP BY user_id
)
SELECT user_id, total,
       DENSE_RANK() OVER (ORDER BY total DESC) AS rnk
FROM user_totals
ORDER BY rnk, user_id;

-- O5.
-- Which users have the highest number of followers and followings?


WITH follower_counts AS (
    SELECT followee_id AS user_id, COUNT(*) followers
    FROM follows GROUP BY followee_id
),
following_counts AS (
    SELECT follower_id AS user_id, COUNT(*) following
    FROM follows GROUP BY follower_id
)
SELECT u.id AS user_id, u.username,
       COALESCE(fr.followers, 0) followers,
       COALESCE(fl.following, 0) following
FROM users u
LEFT JOIN follower_counts fr ON fr.user_id = u.id
LEFT JOIN following_counts fl ON fl.user_id = u.id
ORDER BY u.id;

-- O6.
-- Calculate the average engagement rate (likes, comments) per post for each
-- user.

WITH photo_engagement AS (
    SELECT p.id AS photo_id, p.user_id,
           COALESCE(l.like_count, 0) + COALESCE(c.comment_count, 0) AS engagement
    FROM photos p
    LEFT JOIN (
        SELECT photo_id, COUNT(*) like_count FROM likes GROUP BY photo_id ) l ON l.photo_id = p.id
    LEFT JOIN (
        SELECT photo_id, COUNT(*) comment_count FROM comments GROUP BY photo_id ) c ON c.photo_id = p.id
)
SELECT u.id AS user_id, u.username,
       ROUND(AVG(pe.engagement), 2) average_engagement
FROM photo_engagement pe
JOIN users u ON u.id = pe.user_id
GROUP BY u.id, u.username
ORDER BY u.id;


-- O7.
-- Get the list of users who have never liked any post (users and likes
-- tables)

SELECT u.id, u.username
FROM users u
WHERE NOT EXISTS ( SELECT 1 FROM likes l WHERE l.user_id = u.id)
ORDER BY u.id;


-- O8.
-- How can you leverage user-generated content (posts, hashtags, photo tags)
-- to create more personalized and engaging ad campaigns?

WITH photo_engagement AS (
    SELECT p.id AS photo_id, p.user_id,
           COALESCE(l.like_count, 0) like_count,
           COALESCE(c.comment_count, 0) comment_count
    FROM photos p
    LEFT JOIN (SELECT photo_id, COUNT(*) like_count FROM likes GROUP BY photo_id) l ON l.photo_id = p.id
    LEFT JOIN (SELECT photo_id, COUNT(*) comment_count FROM comments GROUP BY photo_id) c ON c.photo_id = p.id
)
SELECT u.id AS user_id, u.username,
       COALESCE(t.tag_name, 'Untagged') tag_name,
       COUNT(t.id) tag_usage,
       SUM(pe.like_count) total_likes_received,
       SUM(pe.comment_count) total_comments_received,
       SUM(pe.like_count + pe.comment_count) total_engagement
FROM users u
LEFT JOIN photo_engagement pe ON pe.user_id = u.id
LEFT JOIN photo_tags pt ON pt.photo_id = pe.photo_id
LEFT JOIN tags t ON t.id = pt.tag_id
GROUP BY u.id, u.username, t.id, t.tag_name
ORDER BY u.id, total_engagement DESC;


-- O9.
-- Are there any correlations between user activity levels and specific
-- content types (e.g., photos, videos, reels)? How can this information
-- guide content creation and curation strategies?


WITH photo_engagement AS (
    SELECT p.id AS photo_id, p.user_id,
           COALESCE(l.like_count, 0) like_count,
           COALESCE(c.comment_count, 0) comment_count
    FROM photos p
    LEFT JOIN ( SELECT photo_id, COUNT(*) like_count FROM likes GROUP BY photo_id ) l ON l.photo_id = p.id
    LEFT JOIN ( SELECT photo_id, COUNT(*) comment_count  FROM comments GROUP BY photo_id  ) c ON c.photo_id = p.id
)
SELECT user_id,
       COUNT(*) total_posts,
       SUM(like_count) total_likes,
       SUM(comment_count) total_comments,
       SUM(like_count + comment_count) total_engagement
FROM photo_engagement
GROUP BY user_id
ORDER BY total_engagement DESC, user_id;


-- O10.
-- Calculate the total number of likes, comments, and photo tags for each
-- user.

WITH like_totals AS ( SELECT p.user_id, COUNT(*) total_likes FROM photos p JOIN likes l ON l.photo_id = p.id  GROUP BY p.user_id
),
comment_totals AS ( SELECT p.user_id, COUNT(*) total_comments FROM photos p JOIN comments c ON c.photo_id = p.id  GROUP BY p.user_id
),
tag_totals AS ( SELECT p.user_id, COUNT(*) total_photo_tags FROM photos p JOIN photo_tags pt ON pt.photo_id = p.id  GROUP BY p.user_id
)
SELECT u.id AS user_id, u.username,
       COALESCE(l.total_likes, 0) total_likes,
       COALESCE(c.total_comments, 0) total_comments,
       COALESCE(t.total_photo_tags, 0) total_photo_tags
FROM users u
LEFT JOIN like_totals l ON l.user_id = u.id
LEFT JOIN comment_totals c ON c.user_id = u.id
LEFT JOIN tag_totals t ON t.user_id = u.id
ORDER BY u.id;


-- O11.
-- Rank users based on their total engagement (likes, comments, shares) over a
-- month.

select
	u.id as user_id ,
    u.username,
    sum(coalesce(l.like_count,0)) as total_likes,
    sum(coalesce(c.comment_count,0)) as total_comments,
    sum(coalesce(l.like_count,0)+(coalesce(c.comment_count,0))) as total_engagement,
    dense_rank() over(order by sum(coalesce(l.like_count,0)+(coalesce(c.comment_count,0))) desc) as engagement_rank
from users u 
left join photos p on u.id=p.user_id
left join (select photo_id, count(*) as like_count from likes group by photo_id) l on l.photo_id=p.id
left join (select photo_id, count(*) as comment_count from comments group by photo_id) c on c.photo_id=p.id
group by u.id
;



-- O12.
-- Retrieve the hashtags that have been used in posts with the highest average
-- number of likes. Use a CTE to calculate the average likes for each
-- hashtag first.


with post_avg as (
select
	t.id as tag_id,
    t.tag_name,
    avg(coalesce(l.likes_count,0)) as avg_likes_per_photo,
    sum(coalesce(l.likes_count,0)) as total_likes,
    count(distinct pt.photo_id) as total_photos
from tags t
join photo_tags pt on t.id=pt.tag_id
left join ( select photo_id, count(*) as likes_count from likes  group by photo_id ) l on l.photo_id=pt.photo_id
group by t.id, t.tag_name
)

select
	tag_id,
    tag_name,
    avg_likes_per_photo,
    total_likes,
    total_photos
from post_avg
order by avg_likes_per_photo desc
limit 10
;

-- O13.
-- Retrieve the users who have started following someone after being followed
-- by that person.


SELECT DISTINCT u.id AS user_id, u.username
FROM users u
JOIN follows f1 ON f1.follower_id = u.id
JOIN follows f2
  ON f2.follower_id = f1.followee_id
 AND f2.followee_id = f1.follower_id
WHERE f2.created_at < f1.created_at
ORDER BY u.id;




/* =====================================================================
   SUBJECTIVE QUESTIONS
   ===================================================================== */

-- S1.
-- Based on user engagement and activity levels, which users would you
-- consider the most loyal or valuable? How would you reward or incentivize
-- these users?


WITH post_counts AS ( SELECT user_id, COUNT(*) posts  FROM photos GROUP BY user_id
),
given_counts AS (
    SELECT user_id, COUNT(*) engagement_given
    FROM ( SELECT user_id FROM likes UNION ALL SELECT user_id FROM comments  ) x GROUP BY user_id
),
received_counts AS (
    SELECT p.user_id, COUNT(*) engagement_received
    FROM photos p
    JOIN likes l ON l.photo_id = p.id
    GROUP BY p.user_id

    UNION ALL

    SELECT p.user_id, COUNT(*) engagement_received
    FROM photos p
    JOIN comments c ON c.photo_id = p.id
    GROUP BY p.user_id
),
received_by_user AS (
    SELECT user_id, SUM(engagement_received) engagement_received
    FROM received_counts
    GROUP BY user_id
),
scored AS (
    SELECT u.id user_id, u.username,
           COALESCE(p.posts, 0) posts,
           COALESCE(g.engagement_given, 0) engagement_given,
           COALESCE(r.engagement_received, 0) engagement_received,
           COALESCE(g.engagement_given, 0) +
           COALESCE(r.engagement_received, 0) loyalty_score
    FROM users u
    LEFT JOIN post_counts p ON p.user_id = u.id
    LEFT JOIN given_counts g ON g.user_id = u.id
    LEFT JOIN received_by_user r ON r.user_id = u.id
    WHERE COALESCE(p.posts, 0) > 0
      AND COALESCE(g.engagement_given, 0) > 0
      AND COALESCE(r.engagement_received, 0) > 0
)
SELECT user_id, username, posts,
       engagement_given, engagement_received, loyalty_score,
       DENSE_RANK() OVER (
           ORDER BY loyalty_score DESC
       ) loyalty_rank
FROM scored
ORDER BY loyalty_rank, user_id
LIMIT 10;

-- S2.
-- For inactive users, what strategies would you recommend to re-engage them
-- and encourage them to start posting or engaging again?


WITH activity AS (
    SELECT u.id, u.username,
           COALESCE(p.posts, 0) posts,
           COALESCE(l.likes_given, 0) likes_given,
           COALESCE(c.comments_given, 0) comments_given
    FROM users u
    LEFT JOIN (
        SELECT user_id, COUNT(*) posts
        FROM photos GROUP BY user_id
    ) p ON p.user_id = u.id
    LEFT JOIN (
        SELECT user_id, COUNT(*) likes_given
        FROM likes GROUP BY user_id
    ) l ON l.user_id = u.id
    LEFT JOIN (
        SELECT user_id, COUNT(*) comments_given
        FROM comments GROUP BY user_id
    ) c ON c.user_id = u.id
)
SELECT id, username, posts, likes_given, comments_given
FROM activity
WHERE posts = 0
  AND likes_given = 0
  AND comments_given = 0
ORDER BY id;



-- S3.
-- Which hashtags or content topics have the highest engagement rates? How can
-- this information guide content strategy and ad campaigns?


with post_eng as(
select
	p.id as post_id,
    coalesce(l.likes_t,0)+coalesce(c.comments_t,0) as eng
from photos p
left join (select photo_id, count(*) as likes_t from likes group by photo_id) l on p.id=l.photo_id
left join (select photo_id, count(*) as comments_t from comments group by photo_id) c on p.id=c.photo_id
)
select
	t.tag_name,
    count(*) as photos,
    sum(pe.eng) as total_engagement,
    round(avg(pe.eng),2) as avg_post_engagement
from tags t
join photo_tags pt on pt.tag_id=t.id
join post_eng pe on pe.post_id=pt.photo_id
group by t.tag_name
order by avg_post_engagement desc
;


-- S4.
-- Are there any patterns or trends in user engagement based on demographics
-- (age, location, gender) or posting times? How can these insights inform
-- targeted marketing campaigns?


WITH activity AS (
    SELECT u.created_at,
           COALESCE(p.posts, 0) posts,
           COALESCE(l.likes_given, 0) +
           COALESCE(c.comments_given, 0) engagement_given
    FROM users u
    LEFT JOIN ( SELECT user_id, COUNT(*) posts FROM photos GROUP BY user_id ) p ON p.user_id = u.id
    LEFT JOIN ( SELECT user_id, COUNT(*) likes_given FROM likes GROUP BY user_id ) l ON l.user_id = u.id
    LEFT JOIN ( SELECT user_id, COUNT(*) comments_given FROM comments GROUP BY user_id ) c ON c.user_id = u.id
)
SELECT CONCAT(YEAR(created_at), '-Q', QUARTER(created_at)) signup_quarter,
       COUNT(*) users,
       ROUND(AVG(posts), 2) avg_posts,
       ROUND(AVG(engagement_given), 1) avg_engagement,
       SUM(posts = 0 AND engagement_given = 0) inactive_users
FROM activity
GROUP BY YEAR(created_at), QUARTER(created_at)
ORDER BY YEAR(created_at), QUARTER(created_at);

-- S5.
-- Based on follower counts and engagement rates, which users would be ideal
-- candidates for influencer marketing campaigns? How would you approach
-- and collaborate with these influencers?


WITH follower_counts AS (
    SELECT followee_id user_id, COUNT(*) followers FROM follows GROUP BY followee_id
),
photo_engagement AS (
    SELECT p.id photo_id, p.user_id,
           COALESCE(l.like_count, 0) +
           COALESCE(c.comment_count, 0) engagement
    FROM photos p
    LEFT JOIN (  SELECT photo_id, COUNT(*) like_count FROM likes GROUP BY photo_id  ) l ON l.photo_id = p.id
    LEFT JOIN (  SELECT photo_id, COUNT(*) comment_count FROM comments GROUP BY photo_id  ) c ON c.photo_id = p.id
),
engagement_by_user AS ( SELECT user_id, COUNT(*) posts, SUM(engagement) engagements FROM photo_engagement  GROUP BY user_id
)
SELECT u.id user_id, u.username, f.followers,
       e.posts, e.engagements,
       ROUND(e.engagements / NULLIF(e.posts, 0), 1)
           avg_engagement_per_post,
       ROUND(
           e.engagements /
           NULLIF(e.posts * f.followers, 0) * 100, 1
       ) engagement_rate
FROM users u
JOIN follower_counts f ON f.user_id = u.id
JOIN engagement_by_user e ON e.user_id = u.id
ORDER BY engagement_rate DESC, f.followers DESC
LIMIT 10;


-- S6.
-- Based on user behavior and engagement data, how would you segment the user
-- base for targeted marketing campaigns or personalized recommendations?


WITH activity AS (
    SELECT u.id,
           COALESCE(p.posts, 0) posts,
           COALESCE(l.likes_given, 0) +
           COALESCE(c.comments_made, 0) engagement_given
    FROM users u
    LEFT JOIN ( SELECT user_id, COUNT(*) posts FROM photos GROUP BY user_id  ) p ON p.user_id = u.id
    LEFT JOIN ( SELECT user_id, COUNT(*) likes_given  FROM likes GROUP BY user_id ) l ON l.user_id = u.id
    LEFT JOIN ( SELECT user_id, COUNT(*) comments_made  FROM comments GROUP BY user_id ) c ON c.user_id = u.id
),
segmented AS (
    SELECT *,
           CASE
               WHEN posts = 0 AND engagement_given >= 514
                   THEN 'Automated'
               WHEN posts > 0 AND engagement_given > 0
                   THEN 'Loyal users'
               WHEN posts > 0
                   THEN 'Post-only creators'
               ELSE 'Fully inactive'
           END segment
    FROM activity
)
SELECT segment,
       COUNT(*) users,
       ROUND(AVG(posts), 2) avg_posts,
       ROUND(AVG(engagement_given), 1) avg_engagement_given
FROM segmented
GROUP BY segment
ORDER BY users DESC;



-- S7.
-- If data on ad campaigns (impressions, clicks, conversions) is available,
-- how would you measure their effectiveness and optimize future campaigns?


-- a hypothetical query
select
	campaign_id,
    campaign_name,
    impressions, clicks, conversions, spend,
    round(clicks / nullif(impressions,0)*100,2) as click_rate,
    round(conversions / nullif(clicks,0)*100,2) as conversion_rate,
    round(spend / nullif(clicks,0),2) as cost_per_click,
    round(spend/ nullif(conversions,0),2) as cost_per_acquisition,
    round(spend / nullif(impressions,0)*1000,2) as cost_per_impressions,
    round(revenue / nullif(spend,0),2) as roas
from ad_campaigns
order by roas desc
;


-- S8.
-- How can you use user activity data to identify potential brand ambassadors
-- or advocates who could help promote Instagram's initiatives or events?


WITH post_counts AS ( SELECT user_id, COUNT(*) posts FROM photos GROUP BY user_id
),
given_counts AS (
    SELECT user_id, COUNT(*) engagement_given
    FROM ( SELECT user_id FROM likes  UNION ALL  SELECT user_id FROM comments  ) x GROUP BY user_id
),
photo_engagement AS (
    SELECT p.id photo_id, p.user_id,
           COALESCE(l.like_count, 0) +
           COALESCE(c.comment_count, 0) engagement
    FROM photos p
    LEFT JOIN ( SELECT photo_id, COUNT(*) like_count FROM likes GROUP BY photo_id  ) l ON l.photo_id = p.id
    LEFT JOIN ( SELECT photo_id, COUNT(*) comment_count  FROM comments GROUP BY photo_id  ) c ON c.photo_id = p.id
),
received_counts AS (
    SELECT user_id, SUM(engagement) engagement_received FROM photo_engagement GROUP BY user_id
)
SELECT u.id user_id, u.username,
       p.posts, g.engagement_given,
       r.engagement_received,
       ROUND(
           r.engagement_received / NULLIF(p.posts, 0), 1
       ) avg_engagement_per_post
FROM users u
JOIN post_counts p ON p.user_id = u.id
JOIN given_counts g ON g.user_id = u.id
JOIN received_counts r ON r.user_id = u.id
WHERE p.posts >= 4
  AND g.engagement_given >= 140
  AND r.engagement_received / NULLIF(p.posts, 0) >= 63.3
ORDER BY avg_engagement_per_post DESC, g.engagement_given DESC;

-- S9.
-- How would you approach this problem, if the objective and subjective
-- questions weren't given?


/* Start from the business goal, not from the data. The goal is to help Marketing increase engagement, retention and 
acquisition. Every step should serve one of those.*/


-- S10
-- Assuming there's a "User_Interactions" table tracking user engagements, how
-- can you update the "Engagement_Type" column to change all instances of
-- "Like" to "Heart" to align with Instagram's terminology?

SELECT COUNT(*) rows_to_change
FROM User_Interactions
WHERE Engagement_Type = 'Like';

START TRANSACTION;

UPDATE User_Interactions
SET Engagement_Type = 'Heart'
WHERE Engagement_Type = 'Like';

SELECT Engagement_Type, COUNT(*) row_count
FROM User_Interactions
GROUP BY Engagement_Type;

-- COMMIT only after checking the verification result.
-- Use ROLLBACK if the result is incorrect.
COMMIT;

/* ===================================== END OF FILE ===================================== */
